﻿#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$packageDirectory = [IO.Path]::GetFullPath($PSScriptRoot)
$payloadDirectory = Join-Path $packageDirectory 'payload'
$payloadPath = Join-Path $payloadDirectory 'app.asar'
$manifestPath = Join-Path $payloadDirectory 'manifest.json'
$helperPath = Join-Path $payloadDirectory 'apply-update.ps1'
$jobPath = Join-Path $packageDirectory 'install-job.json'
$resultPath = Join-Path $packageDirectory 'result.json'
$windowTitle = 'Cập nhật hiusuy Pro lần đầu'

function Show-UpdateMessage {
    param([string]$Text, [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information)
    [void][System.Windows.Forms.MessageBox]::Show($Text, $windowTitle, [System.Windows.Forms.MessageBoxButtons]::OK, $Icon)
}

function Get-SelectedAppProcesses {
    param([string]$Executable)
    $expected = [IO.Path]::GetFullPath($Executable)
    $processName = [IO.Path]::GetFileName($Executable).Replace("'", "''")
    foreach ($entry in Get-CimInstance Win32_Process -Filter "Name='$processName'") {
        # A missing executable path can mean an elevated process. Do not assume it is safe to replace.
        if ([string]::IsNullOrWhiteSpace($entry.ExecutablePath)) {
            $entry
        } elseif ([IO.Path]::GetFullPath($entry.ExecutablePath).Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
            $entry
        }
    }
}

try {
    foreach ($file in @($payloadPath, $manifestPath, $helperPath)) {
        if (-not [IO.File]::Exists($file)) { throw 'Gói cập nhật thiếu tệp. Hãy giải nén toàn bộ gói rồi mở lại Cap_nhat.cmd.' }
    }
    $manifest = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or $manifest.runtimeSha256 -notmatch '^[a-fA-F0-9]{64}$') {
        throw 'Thông tin kiểm tra của gói cập nhật không hợp lệ.'
    }
    $payloadHash = (Get-FileHash -LiteralPath $payloadPath -Algorithm SHA256).Hash
    if (-not $payloadHash.Equals([string]$manifest.sha256, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Tệp cập nhật bị lỗi hoặc chưa tải đủ. Hãy tải lại gói cập nhật.'
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Bộ này thêm chức năng cập nhật qua mạng vào ứng dụng đang dùng, lên bản $($manifest.version).`r`n`r`nLưu dự án và đóng hiusuy Pro trước khi tiếp tục. Bản ứng dụng cũ sẽ được sao lưu; dự án, cài đặt và bộ nhận diện được giữ nguyên.`r`n`r`nBấm OK, rồi chọn hiusuy Pro.exe của bản đang dùng trên máy này.",
        $windowTitle, [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Information
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }

    $picker = New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title = 'Chọn hiusuy Pro.exe của bản đang dùng'
    $picker.Filter = 'hiusuy Pro.exe|hiusuy Pro.exe|Ứng dụng Windows (*.exe)|*.exe'
    $picker.CheckFileExists = $true
    $picker.Multiselect = $false
    try {
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $executable = [IO.Path]::GetFullPath($picker.FileName)
    } finally { $picker.Dispose() }

    $appDirectory = [IO.Path]::GetDirectoryName($executable)
    $targetAsar = Join-Path $appDirectory 'resources\app.asar'
    if (-not [IO.File]::Exists($targetAsar)) {
        throw 'Thư mục đã chọn không có bản hiusuy Pro phù hợp. Hãy chọn đúng hiusuy Pro.exe bên trong thư mục ứng dụng.'
    }
    $runtimeHash = (Get-FileHash -LiteralPath $executable -Algorithm SHA256).Hash
    if (-not $runtimeHash.Equals([string]$manifest.runtimeSha256, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Bản đang dùng có bộ chạy khác với gói cập nhật này. Chưa thay đổi ứng dụng. Cần gói cập nhật đầy đủ dành cho bản đó.'
    }

    while (@(Get-SelectedAppProcesses -Executable $executable).Count -gt 0) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "hiusuy Pro vẫn đang mở. Hãy lưu dự án, chờ tác vụ đang chạy xong và đóng ứng dụng.`r`n`r`nBấm Retry để kiểm tra lại, hoặc Cancel để dừng cập nhật.",
            $windowTitle, [System.Windows.Forms.MessageBoxButtons]::RetryCancel, [System.Windows.Forms.MessageBoxIcon]::Information
        )
        if ($answer -ne [System.Windows.Forms.DialogResult]::Retry) { exit 0 }
    }

    $backupDirectory = Join-Path $appDirectory ('update-backups\bootstrap-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff'))
    $job = [ordered]@{
        parentPid = 0
        exePath = $executable
        targetAsar = $targetAsar
        payloadPath = $payloadPath
        payloadSha256 = [string]$manifest.sha256
        runtimeSha256 = [string]$manifest.runtimeSha256
        backupPath = (Join-Path $backupDirectory 'app.asar')
        resultPath = $resultPath
        restart = $true
    }
    # These are the bootstrap's only writes. The helper validates and replaces the ASAR transactionally.
    [IO.File]::WriteAllText($jobPath, ($job | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding($false)))
    [IO.File]::WriteAllText($resultPath, '{"ok":false,"message":"Bộ cập nhật chưa ghi kết quả."}', (New-Object Text.UTF8Encoding($false)))
    $helperLiteral = $helperPath.Replace("'", "''")
    $jobLiteral = $jobPath.Replace("'", "''")
    $command = "& '$helperLiteral' -JobPath '$jobLiteral'"
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    $process = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded) -WindowStyle Hidden -Wait -PassThru
    $result = [IO.File]::ReadAllText($resultPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($process.ExitCode -ne 0 -or -not $result.ok) {
        throw ([string]$result.message + "`r`n`r`nNếu Windows báo không có quyền ghi vào thư mục ứng dụng, bấm chuột phải Cap_nhat.cmd và chọn Run as administrator, hoặc dùng bản portable trong thư mục bạn có quyền ghi.")
    }
    Show-UpdateMessage "Đã cập nhật lên bản $($manifest.version) và mở lại hiusuy Pro.`r`n`r`nBản cũ được giữ tại:`r`n$backupDirectory`r`n`r`nDự án, cài đặt và bộ nhận diện không bị thay đổi."
    exit 0
} catch {
    Show-UpdateMessage -Text $_.Exception.Message -Icon ([System.Windows.Forms.MessageBoxIcon]::Error)
    exit 1
}
