param(
    [Parameter(Mandatory = $true)]
    [string]$JobPath
)

# This helper replaces only resources\app.asar. User data and models are never copied.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$job = $null
$resultFile = $null
$stagePath = $null
$restorePath = $null
$replaced = $false
$backupCreated = $false

function Get-AbsolutePath([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or -not [IO.Path]::IsPathRooted($Value)) {
        throw 'Update paths must be absolute.'
    }
    return [IO.Path]::GetFullPath($Value)
}

# Query the tag itself: OneDrive cloud placeholders are reparse points but do not
# redirect the update to a different path. Other tags, including links, are refused.
function Get-ReparseTag([string]$Path) {
    if (-not ('HiusuyUpdate.ReparseInfo' -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace HiusuyUpdate {
    public static class ReparseInfo {
        [StructLayout(LayoutKind.Sequential)]
        private struct FileAttributeTagInfo {
            public uint FileAttributes;
            public uint ReparseTag;
        }
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFileW(string name, uint access,
            uint share, IntPtr security, uint creation, uint flags, IntPtr template);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandleEx(SafeFileHandle handle,
            int informationClass, out FileAttributeTagInfo information, uint size);
        public static uint GetTag(string path) {
            // OPEN_REPARSE_POINT | BACKUP_SEMANTICS supports files and directories.
            using (SafeFileHandle handle = CreateFileW(path, 0, 7, IntPtr.Zero,
                    3, 0x02200000, IntPtr.Zero)) {
                if (handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error());
                FileAttributeTagInfo information;
                if (!GetFileInformationByHandleEx(handle, 9, out information, 8))
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                return information.ReparseTag;
            }
        }
        public static bool IsCloudTag(uint tag) {
            // IO_REPARSE_TAG_CLOUD and IO_REPARSE_TAG_CLOUD_1 through _F.
            return (tag & 0xFFFF0FFFu) == 0x9000001Au;
        }
    }
}
"@
    }
    return [HiusuyUpdate.ReparseInfo]::GetTag($Path)
}

function Assert-NoReparsePoint([string]$Path) {
    $current = Get-AbsolutePath $Path
    while (-not [string]::IsNullOrEmpty($current)) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                $tag = Get-ReparseTag $current
                if (-not [HiusuyUpdate.ReparseInfo]::IsCloudTag($tag)) {
                    throw "Refusing a linked update path: $current"
                }
            }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ([string]::Equals($parent, $current, [StringComparison]::OrdinalIgnoreCase)) { break }
        $current = $parent
    }
}

function Assert-InDirectory([string]$Path, [string]$Directory) {
    $prefix = $Directory.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
    if (-not $Path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Update path is outside the application directory.'
    }
}

function Get-FileHashValue([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-Hash([string]$Path, [string]$Expected) {
    if ($Expected -notmatch '^[a-fA-F0-9]{64}$' -or (Get-FileHashValue $Path) -ne $Expected.ToLowerInvariant()) {
        throw "File verification failed: $([IO.Path]::GetFileName($Path))"
    }
}

function Assert-AppClosed([string]$ExePath) {
    # Do not stop any process: the user may be rendering in another instance.
    $running = Get-CimInstance -ClassName Win32_Process
    foreach ($process in $running) {
        if ($process.ExecutablePath -and [string]::Equals([string]$process.ExecutablePath, $ExePath, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'The application is still running. Close all its windows before updating.'
        }
    }
}

function Write-Result([bool]$Ok, [string]$Message) {
    $result = [ordered]@{ ok = $Ok; message = $Message; time = [DateTime]::UtcNow.ToString('o') }
    if ($backupCreated) { $result.backupPath = $backupPath }
    $json = $result | ConvertTo-Json -Compress
    if ($resultFile) {
        Assert-NoReparsePoint $resultFile
        $parent = [IO.Path]::GetDirectoryName($resultFile)
        [IO.Directory]::CreateDirectory($parent) | Out-Null
        [IO.File]::WriteAllText($resultFile, $json, (New-Object Text.UTF8Encoding($false)))
    }
    Write-Output $json
}

try {
    $jobFile = Get-AbsolutePath $JobPath
    Assert-NoReparsePoint $jobFile
    if ((Get-Item -LiteralPath $jobFile).Length -gt 65536) { throw 'Update job is too large.' }
    $job = [IO.File]::ReadAllText($jobFile) | ConvertFrom-Json
    $resultFile = Get-AbsolutePath ([string]$job.resultPath)
    Assert-NoReparsePoint $resultFile
    $exePath = Get-AbsolutePath ([string]$job.exePath)
    $appDirectory = [IO.Path]::GetDirectoryName($exePath)
    $targetAsar = Get-AbsolutePath ([string]$job.targetAsar)
    $expectedTarget = [IO.Path]::Combine($appDirectory, 'resources', 'app.asar')
    if (-not [string]::Equals($targetAsar, $expectedTarget, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The update may replace only resources\app.asar.'
    }
    $payloadPath = Get-AbsolutePath ([string]$job.payloadPath)
    $backupPath = Get-AbsolutePath ([string]$job.backupPath)
    Assert-InDirectory $targetAsar $appDirectory
    Assert-InDirectory $backupPath ([IO.Path]::Combine($appDirectory, 'update-backups'))
    foreach ($path in @($exePath, $targetAsar, $payloadPath, $backupPath)) { Assert-NoReparsePoint $path }
    if ([string]::Equals($payloadPath, $targetAsar, [StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($payloadPath, $backupPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The downloaded file must be separate from the installed file and backup.'
    }
    if (-not [IO.File]::Exists($exePath) -or -not [IO.File]::Exists($targetAsar) -or -not [IO.File]::Exists($payloadPath)) {
        throw 'An application or update file is missing.'
    }
    if (Test-Path -LiteralPath $backupPath) { throw 'The backup path already exists.' }
    Assert-Hash $exePath ([string]$job.runtimeSha256)
    Assert-Hash $payloadPath ([string]$job.payloadSha256)

    $parentProcessId = [int]$job.parentPid
    if ($parentProcessId -eq $PID) { throw 'The updater cannot wait for itself.' }
    if ($parentProcessId -gt 0) {
        $deadline = [DateTime]::UtcNow.AddSeconds(120)
        while (Get-Process -Id $parentProcessId -ErrorAction SilentlyContinue) {
            if ([DateTime]::UtcNow -ge $deadline) { throw 'Timed out waiting for the application to close.' }
            Start-Sleep -Milliseconds 250
        }
    }
    Assert-AppClosed $exePath
    Assert-Hash $exePath ([string]$job.runtimeSha256)
    Assert-Hash $payloadPath ([string]$job.payloadSha256)
    foreach ($path in @($exePath, $targetAsar, $payloadPath, $backupPath)) { Assert-NoReparsePoint $path }

    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($backupPath)) | Out-Null
    Assert-NoReparsePoint $backupPath
    [IO.File]::Copy($targetAsar, $backupPath, $false)
    $backupCreated = $true
    $stagePath = [IO.Path]::Combine([IO.Path]::GetDirectoryName($targetAsar), '.hiusuy-update-' + [Guid]::NewGuid().ToString('N') + '.asar')
    [IO.File]::Copy($payloadPath, $stagePath, $false)
    Assert-Hash $stagePath ([string]$job.payloadSha256)
    $stream = [IO.File]::Open($stagePath, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    try { $stream.Flush($true) } finally { $stream.Dispose() }
    Assert-AppClosed $exePath
    [IO.File]::Replace($stagePath, $targetAsar, [System.Management.Automation.Language.NullString]::Value)
    $replaced = $true
    Assert-Hash $targetAsar ([string]$job.payloadSha256)
    if ([bool]$job.restart) {
        Start-Process -FilePath $exePath -WorkingDirectory $appDirectory -WindowStyle Hidden -ErrorAction Stop | Out-Null
    }
    Write-Result $true 'Update installed. The previous application file is saved in update-backups.'
    exit 0
} catch {
    $failure = $_.Exception.Message
    if ($replaced -and $backupCreated) {
        try {
            Assert-AppClosed $exePath
            Assert-NoReparsePoint $targetAsar
            Assert-NoReparsePoint $backupPath
            $restorePath = [IO.Path]::Combine([IO.Path]::GetDirectoryName($targetAsar), '.hiusuy-restore-' + [Guid]::NewGuid().ToString('N') + '.asar')
            [IO.File]::Copy($backupPath, $restorePath, $false)
            [IO.File]::Replace($restorePath, $targetAsar, [System.Management.Automation.Language.NullString]::Value)
            $failure += ' The previous application file was restored.'
        } catch {
            $failure += ' Automatic restore failed: ' + $_.Exception.Message + ' The backup is retained.'
        }
    }
    try { Write-Result $false $failure } catch { Write-Output ('Update failed: ' + $failure) }
    exit 1
} finally {
    foreach ($temporaryPath in @($stagePath, $restorePath)) {
        if ($temporaryPath -and [IO.File]::Exists($temporaryPath)) {
            try { Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction Stop } catch { }
        }
    }
}


